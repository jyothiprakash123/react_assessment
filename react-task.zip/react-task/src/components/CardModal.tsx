import React from 'react';
import type { Task } from '../models/Task';

interface Props {
  task: Task;
  onClose: () => void;
}

const CardModal: React.FC<Props> = ({ task, onClose }) => {
  return (
    <div className="modal-backdrop">
      <div className="modal">
        <h2>{task.title}</h2>
        <p>{task.description}</p>
        <p><strong>Created At:</strong> {task.createdAt}</p>
        <p><strong>Created By:</strong> {task.createdBy}</p>
        <p><strong>Assignee:</strong> {task.assignee}</p>
        <p><strong>Tags:</strong> {task.tags.join(', ')}</p>
        <p><strong>Estimation:</strong> {task.estimation}</p>
        <button onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default CardModal;
