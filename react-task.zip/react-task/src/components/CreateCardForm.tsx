import React, { useState } from 'react';
import type { Task } from '../models/Task';

interface Props {
  addTask: (task: Task) => void;
}

const CreateCardForm: React.FC<Props> = ({ addTask }) => {
  const [title, setTitle] = useState('');
  const [assignee, setAssignee] = useState('A');
  const [tag, setTag] = useState('frontend');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const newTask: Task = {
      id: Date.now().toString(),
      title,
      description: '',
      dueDate: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString().split('T')[0],
      createdBy: 'Admin',
      assignee: assignee as any,
      tags: [tag as any],
      estimation: '1 point',
      status: 'Open',
    };

    addTask(newTask);
    setTitle('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Create Card</h2>
      <input
        type="text"
        value={title}
        placeholder="Task Title"
        onChange={(e) => setTitle(e.target.value)}
        required
      />
      <select value={assignee} onChange={(e) => setAssignee(e.target.value)}>
        <option value="A">A</option>
        <option value="B">B</option>
        <option value="C">C</option>
      </select>
      <select value={tag} onChange={(e) => setTag(e.target.value)}>
        <option value="frontend">frontend</option>
        <option value="backend">backend</option>
        <option value="design">design</option>
      </select>
      <button type="submit">Add</button>
    </form>
  );
};

export default CreateCardForm;
