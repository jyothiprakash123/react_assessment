import React from 'react';

const FilterBar = () => {
  return (
    <div style={{ marginBottom: '20px' }}>
      <h2>Advanced Filters (Coming Soon)</h2>
      {/* Future: Dropdowns/chips for AND/OR/NOT filter logic */}
      <p><em>Example: Assignee is B OR Tag is backend</em></p>
    </div>
  );
};

export default FilterBar;
