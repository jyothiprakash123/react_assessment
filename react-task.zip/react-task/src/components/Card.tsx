import React from 'react';
import type { Task } from '../models/Task';
import CardModal from './CardModal';

interface Props {
  task: Task;
}

const Card: React.FC<Props> = ({ task }) => {
  const [showModal, setShowModal] = React.useState(false);

  return (
    <>
      <div className="card" onClick={() => setShowModal(true)}>
        <h3>{task.title}</h3>
        <p><strong>Due:</strong> {task.dueDate}</p>
        <p><strong>Assignee:</strong> {task.assignee}</p>
        <p><strong>Tags:</strong> {task.tags.join(', ')}</p>
      </div>
      {showModal && (
        <CardModal task={task} onClose={() => setShowModal(false)} />
      )}
    </>
  );
};


export default Card;
