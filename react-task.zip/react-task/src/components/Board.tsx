import React from 'react';
import {
  DndContext,
  closestCenter,
  useDroppable,
  useDraggable,
} from '@dnd-kit/core';
import type { Task } from '../models/Task';
import Card from './Card';

const columns = ['Open', 'In Progress', 'Done'] as const;

interface Props {
  tasks: Task[];
  moveTask: (taskId: string, newStatus: Task['status']) => void;
}

const Board: React.FC<Props> = ({ tasks, moveTask }) => {
  const handleDragEnd = (event: any) => {
    const { active, over } = event;
    if (active && over && active.id !== over.id) {
      moveTask(active.id, over.id);
    }
  };

  return (
    <DndContext collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
      <div className="board">
        {columns.map((column) => (
          <Column key={column} id={column} tasks={tasks} />
        ))}
      </div>
    </DndContext>
  );
};

interface ColumnProps {
  id: Task['status'];
  tasks: Task[];
}

const Column: React.FC<ColumnProps> = ({ id, tasks }) => {
  const { setNodeRef } = useDroppable({ id });

  return (
    <div ref={setNodeRef} className="column">
      <h2>{id}</h2>
      {tasks
        .filter((task) => task.status === id)
        .map((task) => (
          <DraggableCard key={task.id} task={task} />
        ))}
    </div>
  );
};

const DraggableCard: React.FC<{ task: Task }> = ({ task }) => {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({
    id: task.id,
  });

  const style = {
    transform: transform
      ? `translate(${transform.x}px, ${transform.y}px)`
      : undefined,
  };

  return (
    <div ref={setNodeRef} style={style} {...listeners} {...attributes}>
      <Card task={task} />
    </div>
  );
};

export default Board;
