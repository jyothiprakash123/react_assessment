import type { Task } from '../models/Task';


export const dummyTasks: Task[] = [
  {
    id: '1',
    title: 'Design Login Page',
    description: 'Create a responsive login page layout',
    dueDate: '2025-06-20',
    createdAt: '2025-06-01',
    createdBy: 'Admin',
    assignee: 'A',
    tags: ['design'],
    estimation: '2 points',
    status: 'Open',
  },
  {
    id: '2',
    title: 'API Integration',
    description: 'Integrate backend with login module',
    dueDate: '2025-06-22',
    createdAt: '2025-06-03',
    createdBy: 'Admin',
    assignee: 'B',
    tags: ['backend'],
    estimation: '3 points',
    status: 'In Progress',
  }
];
