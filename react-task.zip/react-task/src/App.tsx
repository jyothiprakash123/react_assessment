import  { useState } from 'react';
import './styles/main.css';
import { dummyTasks } from './datas/dummyTasks';
import type { Task } from './models/Task';
import Board from './components/Board';
import CreateCardForm from './components/CreateCardForm';
import FilterBar from './components/FilterBar';

function App() {
  const [tasks, setTasks] = useState<Task[]>(dummyTasks);

  const addTask = (task: Task) => {
    setTasks((prev) => [...prev, task]);
  };

  const moveTask = (taskId: string, newStatus: Task['status']) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === taskId ? { ...task, status: newStatus } : task
      )
    );
  };

  return (
    <div className="app-container">
      <h1>Kanban Board</h1>
      <FilterBar />
      <CreateCardForm addTask={addTask} />
      <Board tasks={tasks} moveTask={moveTask} />
    </div>
  );
}

export default App;
